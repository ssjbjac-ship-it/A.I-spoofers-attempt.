import tkinter as tk
from tkinter import ttk
import math
import random
import threading
import time

# ============================================================
# CONFIGURATION - DARK THEME
# ============================================================

BG = "#000000"           # Pure black
PANEL = "#0a0a0a"        # Darker panel
PANEL_2 = "#141414"      # Slightly lighter dark
PANEL_3 = "#1a1a1a"      # Medium dark

TEXT = "#e8e8e8"         # Light gray text
SECONDARY = "#888888"    # Medium gray
TERTIARY = "#555555"     # Dark gray

BORDER = "#2a2a2a"       # Dark border
ACCENT = "#8a2be2"       # Purple accent

# ============================================================
# RAINBOW RING ANIMATION
# ============================================================

class RainbowRing:
    """Animated rainbow ring that rotates clockwise"""
    
    def __init__(self, canvas, x, y, radius, num_dots=48):
        self.canvas = canvas
        self.x = x
        self.y = y
        self.radius = radius
        self.num_dots = num_dots
        self.angle = 0
        self.running = True
        self.dots = []
        
        # Create dots
        self.create_dots()
        
        # Start animation
        self.animate()
    
    def create_dots(self):
        """Create the dots for the rainbow ring"""
        for i in range(self.num_dots):
            # Calculate position
            angle = (2 * math.pi * i) / self.num_dots
            dot_x = self.x + self.radius * math.cos(angle)
            dot_y = self.y + self.radius * math.sin(angle)
            
            # Calculate color based on rainbow gradient
            hue = (i / self.num_dots) * 360
            color = self.hsv_to_rgb(hue, 1.0, 1.0)
            
            # Create dot
            dot = self.canvas.create_oval(
                dot_x - 10, dot_y - 10,
                dot_x + 10, dot_y + 10,
                fill=color,
                outline=color,
                tags="rainbow_dot"
            )
            self.dots.append(dot)
    
    def hsv_to_rgb(self, h, s, v):
        """Convert HSV to RGB hex color"""
        h = h / 60
        i = int(h)
        f = h - i
        p = v * (1 - s)
        q = v * (1 - f * s)
        t = v * (1 - (1 - f) * s)
        
        if i == 0:
            r, g, b = v, t, p
        elif i == 1:
            r, g, b = q, v, p
        elif i == 2:
            r, g, b = p, v, t
        elif i == 3:
            r, g, b = p, q, v
        elif i == 4:
            r, g, b = t, p, v
        else:
            r, g, b = v, p, q
        
        # Convert to hex
        return f'#{int(r*255):02x}{int(g*255):02x}{int(b*255):02x}'
    
    def animate(self):
        """Animate the ring clockwise"""
        if not self.running:
            return
        
        # Rotate all dots clockwise
        self.angle += 0.02
        
        for i, dot in enumerate(self.dots):
            # Calculate new position
            angle = (2 * math.pi * i) / self.num_dots + self.angle
            dot_x = self.x + self.radius * math.cos(angle)
            dot_y = self.y + self.radius * math.sin(angle)
            
            # Update position
            self.canvas.coords(
                dot,
                dot_x - 10, dot_y - 10,
                dot_x + 10, dot_y + 10
            )
        
        # Schedule next frame
        self.canvas.after(16, self.animate)  # ~60 FPS
    
    def stop(self):
        """Stop the animation"""
        self.running = False

# ============================================================
# ROUNDED BUTTON
# ============================================================

class RoundedButton(tk.Canvas):
    """Custom rounded button with hover effects"""
    
    def __init__(self, parent, text, command, bg_color="#8a2be2", width=170, height=42, font=None):
        super().__init__(parent, highlightthickness=0, bg=parent.cget('bg') if hasattr(parent, 'cget') else BG)
        self.command = command
        self.bg_color = bg_color
        self.hover_color = "#9b4dff"
        self.text = text
        self.width = width
        self.height = height
        self.font = font or ("Segoe UI", 10, "bold")
        
        self.configure(width=width, height=height)
        self.bind("<Button-1>", self._on_click)
        self.bind("<Enter>", self._on_enter)
        self.bind("<Leave>", self._on_leave)
        
        self.draw_button()
    
    def draw_button(self, color=None):
        """Draw the rounded button"""
        self.delete("all")
        color = color or self.bg_color
        radius = 12
        
        points = [
            0+radius, 0,
            self.width-radius, 0,
            self.width, 0,
            self.width, 0+radius,
            self.width, self.height-radius,
            self.width, self.height,
            self.width-radius, self.height,
            0+radius, self.height,
            0, self.height,
            0, self.height-radius,
            0, 0+radius,
            0, 0
        ]
        self.create_polygon(points, smooth=True, fill=color, outline="")
        self.create_text(self.width//2, self.height//2, text=self.text, 
                        fill="#e8e8e8", font=self.font, anchor="center")
    
    def _on_click(self, event):
        if self.command:
            self.command()
    
    def _on_enter(self, event):
        self.draw_button(self.hover_color)
        self.config(cursor="hand2")
    
    def _on_leave(self, event):
        self.draw_button(self.bg_color)
        self.config(cursor="")

# ============================================================
# MAIN APPLICATION
# ============================================================

class ThankuBrodieApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Thanku Brodie")
        self.root.geometry("900x700")
        self.root.minsize(800, 600)
        self.root.configure(bg=BG)
        
        self.ring = None
        
        self.setup_styles()
        self.create_interface()
    
    def setup_styles(self):
        style = ttk.Style()
        style.theme_use("clam")
        
        style.configure("TNotebook", background=BG, borderwidth=0)
        style.configure("TNotebook.Tab", 
                       background=PANEL, 
                       foreground=SECONDARY,
                       padding=(30, 14),
                       borderwidth=0,
                       font=("Segoe UI", 10))
        style.map("TNotebook.Tab",
                 background=[("selected", ACCENT)],
                 foreground=[("selected", TEXT)])
        
        style.configure("TFrame", background=BG)
    
    def create_interface(self):
        # Header
        header = tk.Frame(self.root, bg=BG)
        header.pack(fill="x", padx=35, pady=(20, 8))
        
        title_frame = tk.Frame(header, bg=BG)
        title_frame.pack(anchor="w")
        
        title = tk.Label(title_frame, text="Thanku Brodie", bg=BG, fg=TEXT, 
                        font=("Segoe UI", 28, "bold"))
        title.pack(side="left")
        
        accent_bar = tk.Frame(title_frame, bg=ACCENT, height=3, width=180)
        accent_bar.pack(side="bottom", anchor="w", pady=(2, 0))
        
        subtitle = tk.Label(header, text="🌈 Rainbow Ring Animation", 
                           bg=BG, fg=SECONDARY, font=("Segoe UI", 10))
        subtitle.pack(anchor="w", pady=(5, 0))
        
        # Notebook
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill="both", expand=True, padx=25, pady=15)
        
        # Tabs
        self.create_ring_tab()
        self.create_credits_tab()
    
    def create_ring_tab(self):
        """Create the tab with the rainbow ring animation"""
        tab = tk.Frame(self.notebook, bg=BG)
        self.notebook.add(tab, text="  🎨 Rainbow Ring  ")
        
        # Container for ring
        ring_frame = tk.Frame(tab, bg=PANEL, highlightbackground=BORDER, highlightthickness=1)
        ring_frame.pack(fill="both", expand=True, padx=30, pady=30)
        
        # Canvas for animation
        self.canvas = tk.Canvas(ring_frame, bg=PANEL, highlightthickness=0)
        self.canvas.pack(fill="both", expand=True, padx=20, pady=20)
        
        # Center text
        self.center_text = self.canvas.create_text(
            400, 300,
            text="✦ Thanku Brodie ✦",
            fill=TEXT,
            font=("Segoe UI", 20, "bold")
        )
        
        # Subtitle text
        self.sub_text = self.canvas.create_text(
            400, 340,
            text="🌈 Rainbow Ring",
            fill=SECONDARY,
            font=("Segoe UI", 12)
        )
        
        # Bind resize event
        self.canvas.bind("<Configure>", self.on_canvas_resize)
        
        # Create ring after canvas is drawn
        self.root.after(100, self.create_ring)
    
    def on_canvas_resize(self, event):
        """Handle canvas resize"""
        # Update center text position
        self.canvas.coords(self.center_text, event.width // 2, event.height // 2 - 20)
        self.canvas.coords(self.sub_text, event.width // 2, event.height // 2 + 20)
        
        # Recreate ring with new size
        if hasattr(self, 'ring') and self.ring:
            self.ring.stop()
        
        self.create_ring()
    
    def create_ring(self):
        """Create the rainbow ring"""
        if hasattr(self, 'ring') and self.ring:
            self.ring.stop()
            self.canvas.delete("rainbow_dot")
        
        # Calculate center and radius
        width = self.canvas.winfo_width() if self.canvas.winfo_width() > 100 else 600
        height = self.canvas.winfo_height() if self.canvas.winfo_height() > 100 else 400
        
        center_x = width // 2
        center_y = height // 2
        radius = min(width, height) // 2 - 80
        
        if radius > 50:
            self.ring = RainbowRing(self.canvas, center_x, center_y, radius, num_dots=48)
    
    # ============================================================
    # CREDITS TAB
    # ============================================================
    
    def create_credits_tab(self):
        """Create the credits tab with x² variations"""
        tab = tk.Frame(self.notebook, bg=BG)
        self.notebook.add(tab, text="  📜 Credits  ")
        
        # Main frame
        main_frame = tk.Frame(tab, bg=PANEL, highlightbackground=BORDER, highlightthickness=1)
        main_frame.pack(fill="both", expand=True, padx=30, pady=30)
        
        # Header
        tk.Label(main_frame, text="✨ Credits ✨", 
                bg=PANEL, fg=TEXT, font=("Segoe UI", 22, "bold")).pack(pady=(30, 10))
        
        tk.Label(main_frame, text="Special thanks to our amazing contributors", 
                bg=PANEL, fg=SECONDARY, font=("Segoe UI", 12)).pack(pady=(0, 20))
        
        # Divider
        divider = tk.Frame(main_frame, bg=BORDER, height=1)
        divider.pack(fill="x", padx=50, pady=10)
        
        # Credits container
        credits_frame = tk.Frame(main_frame, bg=PANEL)
        credits_frame.pack(fill="both", expand=True, padx=30, pady=20)
        
        # Create 3 name variations of x²
        names = [
            "x² (x squared)",
            "x² (x squared)", 
            "x² (x squared)"
        ]
        
        variations = [
            "✨ Original Creator",
            "🌟 Primary Developer",
            "💎 Lead Architect"
        ]
        
        # Display each name with a special style
        for i, (name, title) in enumerate(zip(names, variations)):
            # Card for each contributor
            card = tk.Frame(credits_frame, bg=PANEL_2, highlightbackground=BORDER, highlightthickness=1)
            card.pack(fill="x", pady=10, padx=20)
            
            # Create a more interesting display
            name_frame = tk.Frame(card, bg=PANEL_2)
            name_frame.pack(fill="x", padx=20, pady=15)
            
            # Icon/emoji
            tk.Label(name_frame, text=title.split()[0] if title else "🌟", 
                    bg=PANEL_2, fg=ACCENT, font=("Segoe UI", 24)).pack(side="left", padx=(0, 15))
            
            # Name with x² styling
            name_label = tk.Label(name_frame, text=name, 
                                 bg=PANEL_2, fg=TEXT, font=("Segoe UI", 18, "bold"))
            name_label.pack(side="left")
            
            # Make x² look special with superscript styling
            # We'll use a smaller font for the ²
            name_parts = name.split("²")
            if len(name_parts) > 1:
                name_label.config(text=name_parts[0])
                # Add superscript ²
                superscript = tk.Label(name_frame, text="²", 
                                      bg=PANEL_2, fg=ACCENT, font=("Segoe UI", 14, "bold"))
                superscript.pack(side="left")
            
            # Title/role
            tk.Label(name_frame, text=f"• {title}", 
                    bg=PANEL_2, fg=SECONDARY, font=("Segoe UI", 11, "italic")).pack(side="left", padx=(15, 0))
            
            # Add some random decorations
            decorations = ["✦", "✧", "★", "☆", "❖", "◆"]
            tk.Label(card, text=random.choice(decorations) * 20, 
                    bg=PANEL_2, fg=BORDER, font=("Segoe UI", 8)).pack(pady=(0, 5))
        
        # Fun fact or message
        message_frame = tk.Frame(main_frame, bg=PANEL_2, highlightbackground=BORDER, highlightthickness=1)
        message_frame.pack(fill="x", padx=30, pady=15)
        
        tk.Label(message_frame, text="💝 Made with love by x² (x squared)", 
                bg=PANEL_2, fg=ACCENT, font=("Segoe UI", 12, "bold")).pack(pady=15)
        
        tk.Label(message_frame, text="x² + x² + x² = ❤️", 
                bg=PANEL_2, fg=SECONDARY, font=("Segoe UI", 11)).pack(pady=(0, 10))
        
        # Close button
        btn_frame = tk.Frame(main_frame, bg=PANEL)
        btn_frame.pack(pady=(10, 20))
        
        RoundedButton(btn_frame, "🔄 Refresh", self.refresh_credits, ACCENT, 180, 42).pack()
    
    def refresh_credits(self):
        """Refresh the credits tab with small variations"""
        # Get current tab
        current_tab = self.notebook.index("current")
        if current_tab == 1:  # Credits tab is index 1
            # Remove and recreate the credits tab
            self.notebook.forget(1)
            self.create_credits_tab()
            self.notebook.select(1)
        
        # Show confirmation
        from tkinter import messagebox
        messagebox.showinfo("Refreshed", "✨ Credits have been refreshed!\n\nx² (x squared) ✨ x² (x squared) ✨ x² (x squared)")

# ============================================================
# RUN APPLICATION
# ============================================================

if __name__ == "__main__":
    root = tk.Tk()
    app = ThankuBrodieApp(root)
    
    def on_closing():
        if app.ring:
            app.ring.stop()
        root.destroy()
    
    root.protocol("WM_DELETE_WINDOW", on_closing)
    root.mainloop()