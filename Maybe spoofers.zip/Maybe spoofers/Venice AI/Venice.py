#!/usr/bin/env python3
"""
Venice AI-47 - Advanced HWID Management System
Dark Grey & Deep Blue Edition with Apex Legends Integration
"""

import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
import random
import string
import json
import os
import urllib.request
import urllib.error
import ssl
from datetime import datetime
from threading import Thread
import time


class VeniceTheme:
    """Dark Grey & Deep Blue color scheme"""
    BG_PRIMARY = "#0A0A0F"           # Near black
    BG_SECONDARY = "#12121A"         # Dark grey-blue
    BG_TERTIARY = "#1A1A28"          # Lighter grey-blue
    BG_CARD = "#151520"              # Card background
    ACCENT_BLUE = "#1E3A5F"            # Deep blue
    ACCENT_BLUE_LIGHT = "#2E5A8F"      # Light deep blue
    ACCENT_BLUE_BRIGHT = "#4A90D9"     # Bright blue
    ACCENT_BLUE_DARK = "#0F1F33"       # Dark navy
    TEXT_PRIMARY = "#E8E8EC"           # Off white
    TEXT_SECONDARY = "#8A8A9A"         # Muted grey
    TEXT_DISABLED = "#5A5A6A"          # Dark grey
    SUCCESS = "#00C853"                # Neon green
    WARNING = "#FFB300"                # Amber
    ERROR = "#FF3D71"                  # Neon red
    INFO = "#00B0FF"                   # Cyan blue


class RoundedButton(tk.Canvas):
    """Custom rounded button widget"""
    def __init__(self, parent, text, command=None, width=120, height=40,
                 bg=VeniceTheme.ACCENT_BLUE, fg=VeniceTheme.TEXT_PRIMARY,
                 hover_bg=VeniceTheme.ACCENT_BLUE_LIGHT, font=None,
                 radius=10, **kwargs):
        super().__init__(parent, width=width, height=height, 
                        bg=parent.cget('bg'), highlightthickness=0, **kwargs)
        
        self.command = command
        self.bg = bg
        self.hover_bg = hover_bg
        self.fg = fg
        self.radius = radius
        self.text = text
        
        if font is None:
            self.font = ("Segoe UI", 11, "bold")
        else:
            self.font = font
        
        self.rect = self.create_rounded_rect(2, 2, width-2, height-2, radius, fill=bg)
        self.txt = self.create_text(width//2, height//2, text=text, 
                                   fill=fg, font=self.font)
        
        self.bind("<Enter>", self.on_enter)
        self.bind("<Leave>", self.on_leave)
        self.bind("<Button-1>", self.on_click)
        self.bind("<ButtonRelease-1>", self.on_release)
    
    def create_rounded_rect(self, x1, y1, x2, y2, radius, **kwargs):
        """Create a rounded rectangle"""
        points = [
            x1+radius, y1,
            x2-radius, y1,
            x2, y1,
            x2, y1+radius,
            x2, y2-radius,
            x2, y2,
            x2-radius, y2,
            x1+radius, y2,
            x1, y2,
            x1, y2-radius,
            x1, y1+radius,
            x1, y1
        ]
        return self.create_polygon(points, smooth=True, **kwargs)
    
    def on_enter(self, event):
        self.itemconfig(self.rect, fill=self.hover_bg)
        self.config(cursor="hand2")
    
    def on_leave(self, event):
        self.itemconfig(self.rect, fill=self.bg)
    
    def on_click(self, event):
        self.itemconfig(self.rect, fill=self.bg)
    
    def on_release(self, event):
        self.itemconfig(self.rect, fill=self.hover_bg)
        if self.command:
            self.command()
    
    def config_text(self, text):
        self.itemconfig(self.txt, text=text)
    
    def config_bg(self, bg):
        self.bg = bg
        self.itemconfig(self.rect, fill=bg)


class VeniceAI47:
    def __init__(self, root):
        self.root = root
        self.root.title("Venice AI-47")
        self.root.geometry("1300x850")
        self.root.configure(bg=VeniceTheme.BG_PRIMARY)
        self.root.minsize(1100, 750)
        
        # Window drag variables
        self.offset_x = 0
        self.offset_y = 0
        
        # State
        self.spoofed_ids = {}
        self.is_spoofed = False
        self.apex_version = "Fetching..."
        
        self.setup_styles()
        self.create_title_bar()
        self.create_main_layout()
        self.create_sidebar()
        self.create_content_area()
        self.create_status_bar()
        
        # Center window
        self.root.update_idletasks()
        width = self.root.winfo_width()
        height = self.root.winfo_height()
        x = (self.root.winfo_screenwidth() // 2) - (width // 2)
        y = (self.root.winfo_screenheight() // 2) - (height // 2)
        self.root.geometry(f'{width}x{height}+{x}+{y}')
        
        # Initial data load
        self.scan_hardware()
        
        # Fetch Apex version in background
        Thread(target=self.fetch_apex_version, daemon=True).start()
    
    def setup_styles(self):
        """Configure ttk styles for deep blue theme"""
        self.style = ttk.Style()
        self.style.theme_use('clam')
        
        # Frame styles
        self.style.configure("Venice.TFrame", background=VeniceTheme.BG_PRIMARY)
        self.style.configure("VeniceSecondary.TFrame", background=VeniceTheme.BG_SECONDARY)
        
        # Treeview
        self.style.configure("Venice.Treeview",
            background=VeniceTheme.BG_SECONDARY,
            foreground=VeniceTheme.TEXT_PRIMARY,
            fieldbackground=VeniceTheme.BG_SECONDARY,
            rowheight=40,
            font=("Segoe UI", 10)
        )
        self.style.configure("Venice.Treeview.Heading",
            background=VeniceTheme.ACCENT_BLUE_DARK,
            foreground=VeniceTheme.TEXT_PRIMARY,
            font=("Segoe UI", 11, "bold"),
            padding=12
        )
        self.style.map("Venice.Treeview",
            background=[("selected", VeniceTheme.ACCENT_BLUE)],
            foreground=[("selected", VeniceTheme.TEXT_PRIMARY)]
        )
        
        # Progress bar
        self.style.configure("Venice.Horizontal.TProgressbar",
            background=VeniceTheme.ACCENT_BLUE_BRIGHT,
            troughcolor=VeniceTheme.BG_TERTIARY,
            borderwidth=0,
            lightcolor=VeniceTheme.ACCENT_BLUE_LIGHT,
            darkcolor=VeniceTheme.ACCENT_BLUE
        )
        
        # Scrollbar
        self.style.configure("Venice.Vertical.TScrollbar",
            background=VeniceTheme.BG_TERTIARY,
            troughcolor=VeniceTheme.BG_SECONDARY,
            borderwidth=0,
            arrowcolor=VeniceTheme.TEXT_SECONDARY
        )
    
    def fetch_apex_version(self):
        """Fetch current Apex Legends version"""
        try:
            # Using Steam API to get version info
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
            
            url = "https://api.steamcmd.net/v1/info/1172470"
            req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
            
            with urllib.request.urlopen(req, context=ctx, timeout=5) as response:
                data = json.loads(response.read().decode())
                
                if 'data' in data and '1172470' in data['data']:
                    app_data = data['data']['1172470']
                    if 'depots' in app_data and 'branches' in app_data['depots']:
                        public_branch = app_data['depots']['branches'].get('public', {})
                        buildid = public_branch.get('buildid', 'Unknown')
                        timeupdated = public_branch.get('timeupdated', '')
                        
                        if timeupdated:
                            from datetime import datetime
                            updated = datetime.fromtimestamp(int(timeupdated))
                            version_str = f"Build {buildid} ({updated.strftime('%Y-%m-%d')})"
                        else:
                            version_str = f"Build {buildid}"
                        
                        self.apex_version = version_str
                    else:
                        self.apex_version = "Season 24 - Build Unknown"
                else:
                    self.apex_version = "Season 24 - Marked"
                    
        except Exception as e:
            # Fallback to known version info
            self.apex_version = "Season 24: Marked (Aug 2026)"
        
        # Update UI if dashboard exists
        self.root.after(0, self.update_apex_display)
    
    def update_apex_display(self):
        """Update the Apex version display"""
        if hasattr(self, 'apex_version_label'):
            self.apex_version_label.config(text=f"APEX LEGENDS: {self.apex_version}")
    
    def create_title_bar(self):
        """Custom title bar with deep blue accent"""
        self.title_bar = tk.Frame(self.root, bg=VeniceTheme.BG_SECONDARY, height=45)
        self.title_bar.pack(fill=tk.X, side=tk.TOP)
        self.title_bar.pack_propagate(False)
        
        # Logo section
        logo_frame = tk.Frame(self.title_bar, bg=VeniceTheme.BG_SECONDARY)
        logo_frame.pack(side=tk.LEFT, padx=15)
        
        # AI-47 Logo
        tk.Label(logo_frame, text="◈", 
                font=("Segoe UI", 20),
                bg=VeniceTheme.BG_SECONDARY,
                fg=VeniceTheme.ACCENT_BLUE_BRIGHT).pack(side=tk.LEFT)
        
        tk.Label(logo_frame, text="VENICE", 
                font=("Segoe UI", 14, "bold"),
                bg=VeniceTheme.BG_SECONDARY,
                fg=VeniceTheme.TEXT_PRIMARY).pack(side=tk.LEFT, padx=(5, 0))
        
        tk.Label(logo_frame, text="AI-47", 
                font=("Segoe UI", 14),
                bg=VeniceTheme.BG_SECONDARY,
                fg=VeniceTheme.ACCENT_BLUE_BRIGHT).pack(side=tk.LEFT)
        
        # Apex Version Badge
        self.apex_version_label = tk.Label(self.title_bar, 
                                          text="APEX LEGENDS: Checking...",
                                          font=("Segoe UI", 9),
                                          bg=VeniceTheme.ACCENT_BLUE_DARK,
                                          fg=VeniceTheme.ACCENT_BLUE_BRIGHT,
                                          padx=15, pady=5)
        self.apex_version_label.pack(side=tk.LEFT, padx=20)
        
        # Window controls
        btn_frame = tk.Frame(self.title_bar, bg=VeniceTheme.BG_SECONDARY)
        btn_frame.pack(side=tk.RIGHT, padx=10)
        
        for text, color, cmd in [("−", VeniceTheme.TEXT_SECONDARY, self.minimize_window),
                                  ("×", VeniceTheme.ERROR, self.root.destroy)]:
            btn = tk.Button(btn_frame, text=text, font=("Segoe UI", 14),
                          bg=VeniceTheme.BG_SECONDARY, fg=VeniceTheme.TEXT_PRIMARY,
                          bd=0, width=3, cursor="hand2",
                          activebackground=color,
                          activeforeground=VeniceTheme.TEXT_PRIMARY,
                          command=cmd)
            btn.pack(side=tk.LEFT, padx=2)
        
        # Draggable
        self.title_bar.bind("<Button-1>", self.start_move)
        self.title_bar.bind("<B1-Motion>", self.on_move)
    
    def start_move(self, event):
        self.offset_x = event.x
        self.offset_y = event.y
    
    def on_move(self, event):
        x = self.root.winfo_x() + event.x - self.offset_x
        y = self.root.winfo_y() + event.y - self.offset_y
        self.root.geometry(f"+{x}+{y}")
    
    def minimize_window(self):
        self.root.iconify()
    
    def create_main_layout(self):
        """Create main container"""
        self.main_container = tk.Frame(self.root, bg=VeniceTheme.BG_PRIMARY)
        self.main_container.pack(fill=tk.BOTH, expand=True)
    
    def create_sidebar(self):
        """Create left sidebar with deep blue accents"""
        self.sidebar = tk.Frame(self.main_container, 
                               bg=VeniceTheme.BG_SECONDARY, width=240)
        self.sidebar.pack(side=tk.LEFT, fill=tk.Y)
        self.sidebar.pack_propagate(False)
        
        # System info card
        info_card = tk.Frame(self.sidebar, bg=VeniceTheme.ACCENT_BLUE_DARK,
                            height=120)
        info_card.pack(fill=tk.X, padx=15, pady=15)
        info_card.pack_propagate(False)
        
        tk.Label(info_card, text="◈", font=("Segoe UI", 28),
                bg=VeniceTheme.ACCENT_BLUE_DARK,
                fg=VeniceTheme.ACCENT_BLUE_BRIGHT).pack(pady=(15, 0))
        
        tk.Label(info_card, text="AI-47", font=("Segoe UI", 12, "bold"),
                bg=VeniceTheme.ACCENT_BLUE_DARK,
                fg=VeniceTheme.TEXT_PRIMARY).pack()
        
        tk.Label(info_card, text="SYSTEM ACTIVE", font=("Segoe UI", 9),
                bg=VeniceTheme.ACCENT_BLUE_DARK,
                fg=VeniceTheme.SUCCESS).pack()
        
        # Navigation with rounded buttons
        nav_frame = tk.Frame(self.sidebar, bg=VeniceTheme.BG_SECONDARY)
        nav_frame.pack(fill=tk.X, padx=15, pady=20)
        
        nav_items = [
            ("Dashboard", self.show_dashboard),
            ("HWID Spoofer", self.show_spoofer),
            ("System Cleaner", self.show_cleaner),
            ("Settings", self.show_settings),
            ("Logs", self.show_logs),
        ]
        
        self.nav_buttons = []
        for i, (text, cmd) in enumerate(nav_items):
            is_active = i == 0
            bg = VeniceTheme.ACCENT_BLUE if is_active else VeniceTheme.BG_TERTIARY
            hover = VeniceTheme.ACCENT_BLUE_LIGHT
            
            btn = RoundedButton(nav_frame, text=text, command=cmd,
                              width=200, height=45,
                              bg=bg, hover_bg=hover,
                              font=("Segoe UI", 11, "bold" if is_active else "normal"))
            btn.pack(pady=5)
            self.nav_buttons.append((btn, text))
        
        # Bottom stats
        bottom_frame = tk.Frame(self.sidebar, bg=VeniceTheme.BG_SECONDARY)
        bottom_frame.pack(side=tk.BOTTOM, fill=tk.X, padx=15, pady=15)
        
        self.status_indicator = tk.Label(bottom_frame, 
                                        text="● READY",
                                        font=("Segoe UI", 10, "bold"),
                                        bg=VeniceTheme.BG_SECONDARY,
                                        fg=VeniceTheme.SUCCESS)
        self.status_indicator.pack(anchor=tk.W)
        
        tk.Label(bottom_frame, text="v2.4.7 | ELITE", 
                font=("Segoe UI", 9),
                bg=VeniceTheme.BG_SECONDARY,
                fg=VeniceTheme.ACCENT_BLUE_BRIGHT).pack(anchor=tk.W, pady=(5, 0))
    
    def set_active_nav(self, index):
        """Update navigation button states"""
        for i, (btn, text) in enumerate(self.nav_buttons):
            if i == index:
                btn.config_bg(VeniceTheme.ACCENT_BLUE)
                btn.font = ("Segoe UI", 11, "bold")
            else:
                btn.config_bg(VeniceTheme.BG_TERTIARY)
                btn.font = ("Segoe UI", 11, "normal")
    
    def create_content_area(self):
        """Create main content area"""
        self.content = tk.Frame(self.main_container, bg=VeniceTheme.BG_PRIMARY)
        self.content.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=30, pady=30)
        
        self.show_dashboard()
    
    def clear_content(self):
        """Clear content area"""
        for widget in self.content.winfo_children():
            widget.destroy()
    
    def show_dashboard(self):
        """Display dashboard view"""
        self.set_active_nav(0)
        self.clear_content()
        
        # Header
        header = tk.Frame(self.content, bg=VeniceTheme.BG_PRIMARY)
        header.pack(fill=tk.X, pady=(0, 25))
        
        tk.Label(header, text="Dashboard", 
                font=("Segoe UI", 32, "bold"),
                bg=VeniceTheme.BG_PRIMARY,
                fg=VeniceTheme.TEXT_PRIMARY).pack(anchor=tk.W)
        
        tk.Label(header, text="Venice AI-47 System Overview", 
                font=("Segoe UI", 12),
                bg=VeniceTheme.BG_PRIMARY,
                fg=VeniceTheme.TEXT_SECONDARY).pack(anchor=tk.W)
        
        # Stats grid
        stats_frame = tk.Frame(self.content, bg=VeniceTheme.BG_PRIMARY)
        stats_frame.pack(fill=tk.X, pady=20)
        
        stats = [
            ("Hardware IDs", "7 Active", VeniceTheme.ACCENT_BLUE_BRIGHT),
            ("Apex Status", "Compatible", VeniceTheme.SUCCESS),
            ("Last Spoof", "Never", VeniceTheme.TEXT_SECONDARY),
            ("System", "Clean", VeniceTheme.INFO),
        ]
        
        for title, value, color in stats:
            card = tk.Frame(stats_frame, bg=VeniceTheme.BG_CARD,
                          width=220, height=130)
            card.pack(side=tk.LEFT, padx=(0, 20))
            card.pack_propagate(False)
            
            # Top accent line
            tk.Frame(card, bg=color, height=3).pack(fill=tk.X)
            
            tk.Label(card, text=title, font=("Segoe UI", 11),
                    bg=VeniceTheme.BG_CARD,
                    fg=VeniceTheme.TEXT_SECONDARY).pack(anchor=tk.W, padx=20, pady=(20, 5))
            
            tk.Label(card, text=value, font=("Segoe UI", 20, "bold"),
                    bg=VeniceTheme.BG_CARD,
                    fg=color).pack(anchor=tk.W, padx=20)
        
        # Apex Info Card
        apex_card = tk.LabelFrame(self.content, text=" Apex Legends Integration ",
                                  font=("Segoe UI", 12, "bold"),
                                  bg=VeniceTheme.BG_PRIMARY,
                                  fg=VeniceTheme.ACCENT_BLUE_BRIGHT,
                                  bd=1, relief=tk.SOLID)
        apex_card.pack(fill=tk.X, pady=20)
        
        apex_content = tk.Frame(apex_card, bg=VeniceTheme.BG_PRIMARY)
        apex_content.pack(fill=tk.X, padx=20, pady=15)
        
        tk.Label(apex_content, text="Current Game Version:", 
                font=("Segoe UI", 11),
                bg=VeniceTheme.BG_PRIMARY,
                fg=VeniceTheme.TEXT_SECONDARY).pack(anchor=tk.W)
        
        self.apex_version_display = tk.Label(apex_content, 
                                            text=self.apex_version,
                                            font=("Segoe UI", 14, "bold"),
                                            bg=VeniceTheme.BG_PRIMARY,
                                            fg=VeniceTheme.ACCENT_BLUE_BRIGHT)
        self.apex_version_display.pack(anchor=tk.W, pady=(5, 10))
        
        tk.Label(apex_content, text="Status: Undetected | Recommended: Spoof before launch",
                font=("Segoe UI", 10),
                bg=VeniceTheme.BG_PRIMARY,
                fg=VeniceTheme.SUCCESS).pack(anchor=tk.W)
        
        # Quick Actions
        actions_frame = tk.LabelFrame(self.content, text=" Quick Actions ",
                                      font=("Segoe UI", 12, "bold"),
                                      bg=VeniceTheme.BG_PRIMARY,
                                      fg=VeniceTheme.ACCENT_BLUE_BRIGHT,
                                      bd=1, relief=tk.SOLID)
        actions_frame.pack(fill=tk.X, pady=20)
        
        btn_container = tk.Frame(actions_frame, bg=VeniceTheme.BG_PRIMARY)
        btn_container.pack(padx=20, pady=20)
        
        RoundedButton(btn_container, text="⚡ SPOOF ALL", 
                     command=self.show_spoofer,
                     width=150, height=45,
                     bg=VeniceTheme.ACCENT_BLUE,
                     hover_bg=VeniceTheme.ACCENT_BLUE_LIGHT).pack(side=tk.LEFT, padx=10)
        
        RoundedButton(btn_container, text="🧹 CLEAN TRACES", 
                     command=self.show_cleaner,
                     width=150, height=45,
                     bg=VeniceTheme.BG_TERTIARY,
                     hover_bg=VeniceTheme.ACCENT_BLUE).pack(side=tk.LEFT, padx=10)
        
        RoundedButton(btn_container, text="📊 VIEW LOGS", 
                     command=self.show_logs,
                     width=150, height=45,
                     bg=VeniceTheme.BG_TERTIARY,
                     hover_bg=VeniceTheme.ACCENT_BLUE).pack(side=tk.LEFT, padx=10)
        
        # Activity Log
        log_frame = tk.LabelFrame(self.content, text=" System Activity ",
                                font=("Segoe UI", 12, "bold"),
                                bg=VeniceTheme.BG_PRIMARY,
                                fg=VeniceTheme.ACCENT_BLUE_BRIGHT,
                                bd=1, relief=tk.SOLID)
        log_frame.pack(fill=tk.BOTH, expand=True, pady=20)
        
        self.activity_text = scrolledtext.ScrolledText(
            log_frame,
            bg=VeniceTheme.BG_CARD,
            fg=VeniceTheme.TEXT_PRIMARY,
            font=("JetBrains Mono", 10),
            padx=10, pady=10,
            bd=0,
            state=tk.DISABLED
        )
        self.activity_text.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        self.log_activity("Venice AI-47 initialized")
        self.log_activity("Hardware detection module loaded")
        self.log_activity("Apex Legends version check initiated")
        self.log_activity("System ready for HWID operations")
    
    def show_spoofer(self):
        """Display HWID spoofer view"""
        self.set_active_nav(1)
        self.clear_content()
        
        # Header
        header = tk.Frame(self.content, bg=VeniceTheme.BG_PRIMARY)
        header.pack(fill=tk.X, pady=(0, 25))
        
        tk.Label(header, text="HWID Spoofer", 
                font=("Segoe UI", 32, "bold"),
                bg=VeniceTheme.BG_PRIMARY,
                fg=VeniceTheme.TEXT_PRIMARY).pack(anchor=tk.W)
        
        tk.Label(header, text="Modify hardware identifiers for Apex Legends", 
                font=("Segoe UI", 12),
                bg=VeniceTheme.BG_PRIMARY,
                fg=VeniceTheme.TEXT_SECONDARY).pack(anchor=tk.W)
        
        # Hardware tree
        tree_frame = tk.Frame(self.content, bg=VeniceTheme.BG_PRIMARY)
        tree_frame.pack(fill=tk.BOTH, expand=True, pady=20)
        
        columns = ("Component", "Original ID", "Spoofed ID", "Status")
        self.hwid_tree = ttk.Treeview(tree_frame, columns=columns, 
                                      show="headings", style="Venice.Treeview",
                                      height=12)
        
        for col in columns:
            self.hwid_tree.heading(col, text=col)
            self.hwid_tree.column(col, width=250 if col != "Status" else 120)
        
        scrollbar = ttk.Scrollbar(tree_frame, orient=tk.VERTICAL, 
                                 command=self.hwid_tree.yview)
        self.hwid_tree.configure(yscrollcommand=scrollbar.set)
        
        self.hwid_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        self.update_hwid_tree()
        
        # Control buttons with rounded style
        control_frame = tk.Frame(self.content, bg=VeniceTheme.BG_PRIMARY)
        control_frame.pack(fill=tk.X, pady=20)
        
        self.spoof_btn = RoundedButton(control_frame, text="⚡ SPOOF ALL HWIDs",
                                      command=self.spoof_hardware,
                                      width=200, height=50,
                                      bg=VeniceTheme.ACCENT_BLUE,
                                      hover_bg=VeniceTheme.ACCENT_BLUE_LIGHT,
                                      font=("Segoe UI", 13, "bold"))
        self.spoof_btn.pack(side=tk.LEFT, padx=5)
        
        self.restore_btn = RoundedButton(control_frame, text="↺ RESTORE ORIGINAL",
                                        command=self.restore_hardware,
                                        width=180, height=50,
                                        bg=VeniceTheme.BG_TERTIARY,
                                        hover_bg=VeniceTheme.ERROR,
                                        font=("Segoe UI", 11))
        self.restore_btn.pack(side=tk.LEFT, padx=5)
        
        # Progress
        self.progress_frame = tk.Frame(self.content, bg=VeniceTheme.BG_PRIMARY)
        self.progress_frame.pack(fill=tk.X, pady=10)
        self.progress_frame.pack_forget()
        
        self.progress_label = tk.Label(self.progress_frame, 
                                      text="Initializing...",
                                      font=("Segoe UI", 10),
                                      bg=VeniceTheme.BG_PRIMARY,
                                      fg=VeniceTheme.TEXT_SECONDARY)
        self.progress_label.pack(anchor=tk.W)
        
        self.progress = ttk.Progressbar(self.progress_frame, 
                                       mode="determinate",
                                       style="Venice.Horizontal.TProgressbar")
        self.progress.pack(fill=tk.X, pady=10)
    
    def show_cleaner(self):
        """Display system cleaner view"""
        self.set_active_nav(2)
        self.clear_content()
        
        header = tk.Frame(self.content, bg=VeniceTheme.BG_PRIMARY)
        header.pack(fill=tk.X, pady=(0, 25))
        
        tk.Label(header, text="System Cleaner", 
                font=("Segoe UI", 32, "bold"),
                bg=VeniceTheme.BG_PRIMARY,
                fg=VeniceTheme.TEXT_PRIMARY).pack(anchor=tk.W)
        
        options_frame = tk.LabelFrame(self.content, text=" Cleaning Targets ",
                                     font=("Segoe UI", 12, "bold"),
                                     bg=VeniceTheme.BG_PRIMARY,
                                     fg=VeniceTheme.ACCENT_BLUE_BRIGHT,
                                     bd=1, relief=tk.SOLID)
        options_frame.pack(fill=tk.X, pady=20)
        
        self.clean_vars = {}
        clean_options = [
            ("Registry traces (Apex, EA, Steam)", True),
            ("Temporary files", True),
            ("Event logs", False),
            ("Prefetch data", True),
            ("Recent documents", False),
            ("Browser cache & cookies", False),
        ]
        
        for opt, default in clean_options:
            var = tk.BooleanVar(value=default)
            self.clean_vars[opt] = var
            
            cb = tk.Checkbutton(options_frame, text=opt,
                               variable=var,
                               font=("Segoe UI", 11),
                               bg=VeniceTheme.BG_PRIMARY,
                               fg=VeniceTheme.TEXT_PRIMARY,
                               selectcolor=VeniceTheme.ACCENT_BLUE,
                               activebackground=VeniceTheme.BG_PRIMARY,
                               activeforeground=VeniceTheme.TEXT_PRIMARY)
            cb.pack(anchor=tk.W, padx=20, pady=10)
        
        RoundedButton(self.content, text="🧹 START CLEANING",
                     command=self.run_cleaner,
                     width=200, height=50,
                     bg=VeniceTheme.ACCENT_BLUE,
                     hover_bg=VeniceTheme.ACCENT_BLUE_LIGHT,
                     font=("Segoe UI", 13, "bold")).pack(anchor=tk.W, pady=20)
    
    def show_settings(self):
        """Display settings view"""
        self.set_active_nav(3)
        self.clear_content()
        
        header = tk.Frame(self.content, bg=VeniceTheme.BG_PRIMARY)
        header.pack(fill=tk.X, pady=(0, 25))
        
        tk.Label(header, text="Settings", 
                font=("Segoe UI", 32, "bold"),
                bg=VeniceTheme.BG_PRIMARY,
                fg=VeniceTheme.TEXT_PRIMARY).pack(anchor=tk.W)
        
        sections = [
            ("General", [
                ("Start with Windows", False),
                ("Minimize to system tray", True),
                ("Auto-check for updates", True),
            ]),
            ("Spoofing", [
                ("Randomize on startup", False),
                ("Backup original IDs", True),
                ("Auto-restore on exit", False),
            ]),
            ("Apex Integration", [
                ("Auto-detect game launch", True),
                ("Pre-launch spoof", True),
                ("Show version notifications", True),
            ]),
        ]
        
        for section_name, options in sections:
            frame = tk.LabelFrame(self.content, text=f" {section_name} ",
                                 font=("Segoe UI", 12, "bold"),
                                 bg=VeniceTheme.BG_PRIMARY,
                                 fg=VeniceTheme.ACCENT_BLUE_BRIGHT,
                                 bd=1, relief=tk.SOLID)
            frame.pack(fill=tk.X, pady=10)
            
            for opt_text, default in options:
                var = tk.BooleanVar(value=default)
                cb = tk.Checkbutton(frame, text=opt_text,
                                  variable=var,
                                  font=("Segoe UI", 11),
                                  bg=VeniceTheme.BG_PRIMARY,
                                  fg=VeniceTheme.TEXT_PRIMARY,
                                  selectcolor=VeniceTheme.ACCENT_BLUE,
                                  activebackground=VeniceTheme.BG_PRIMARY)
                cb.pack(anchor=tk.W, padx=20, pady=8)
    
    def show_logs(self):
        """Display logs view"""
        self.set_active_nav(4)
        self.clear_content()
        
        header = tk.Frame(self.content, bg=VeniceTheme.BG_PRIMARY)
        header.pack(fill=tk.X, pady=(0, 25))
        
        tk.Label(header, text="System Logs", 
                font=("Segoe UI", 32, "bold"),
                bg=VeniceTheme.BG_PRIMARY,
                fg=VeniceTheme.TEXT_PRIMARY).pack(anchor=tk.W)
        
        log_frame = tk.Frame(self.content, bg=VeniceTheme.BG_CARD, bd=1, relief=tk.SOLID)
        log_frame.pack(fill=tk.BOTH, expand=True)
        
        self.log_text = scrolledtext.ScrolledText(
            log_frame,
            bg=VeniceTheme.BG_CARD,
            fg=VeniceTheme.TEXT_PRIMARY,
            font=("JetBrains Mono", 10),
            padx=10, pady=10,
            bd=0,
            state=tk.NORMAL
        )
        self.log_text.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        logs = [
            "[2026-08-15 14:32:01] Venice AI-47 initialized",
            "[2026-08-15 14:32:02] Loading kernel driver interface",
            "[2026-08-15 14:32:02] SMBIOS module loaded",
            "[2026-08-15 14:32:03] Disk controller hooks active",
            "[2026-08-15 14:32:03] Network adapter monitor ready",
            "[2026-08-15 14:32:04] GPU spoofing module initialized",
            "[2026-08-15 14:32:04] Apex Legends API connected",
            "[2026-08-15 14:32:05] System ready for operations",
        ]
        for log in logs:
            self.log_text.insert(tk.END, log + "\n")
        self.log_text.configure(state=tk.DISABLED)
        
        RoundedButton(self.content, text="📥 Export Logs",
                     command=lambda: None,
                     width=150, height=40,
                     bg=VeniceTheme.BG_TERTIARY,
                     hover_bg=VeniceTheme.ACCENT_BLUE).pack(anchor=tk.E, pady=15)
    
    def create_status_bar(self):
        """Create bottom status bar"""
        self.status_bar = tk.Frame(self.root, bg=VeniceTheme.BG_SECONDARY, height=35)
        self.status_bar.pack(side=tk.BOTTOM, fill=tk.X)
        self.status_bar.pack_propagate(False)
        
        self.status_text = tk.Label(self.status_bar, 
                                   text="Venice AI-47 Ready",
                                   font=("Segoe UI", 10),
                                   bg=VeniceTheme.BG_SECONDARY,
                                   fg=VeniceTheme.TEXT_SECONDARY)
        self.status_text.pack(side=tk.LEFT, padx=20)
        
        self.version_text = tk.Label(self.status_bar, 
                                    text="v2.4.7 ELITE | Apex: Compatible",
                                    font=("Segoe UI", 10),
                                    bg=VeniceTheme.BG_SECONDARY,
                                    fg=VeniceTheme.ACCENT_BLUE_BRIGHT)
        self.version_text.pack(side=tk.RIGHT, padx=20)
    
    def scan_hardware(self):
        """Simulate hardware scanning"""
        self.hardware_data = {
            "Motherboard": self.generate_hwid(),
            "BIOS": self.generate_hwid(),
            "CPU": self.generate_hwid(),
            "Disk 0": self.generate_hwid(),
            "Disk 1": self.generate_hwid(),
            "MAC Address": self.generate_mac(),
            "GPU": self.generate_hwid(),
        }
    
    def generate_hwid(self):
        """Generate random hardware ID"""
        return ''.join(random.choices(string.hexdigits.upper(), k=16))
    
    def generate_mac(self):
        """Generate random MAC address"""
        return ':'.join([''.join(random.choices(string.hexdigits.upper(), k=2)) 
                        for _ in range(6)])
    
    def update_hwid_tree(self):
        """Update treeview with hardware data"""
        for item in self.hwid_tree.get_children():
            self.hwid_tree.delete(item)
        
        for component, hwid in self.hardware_data.items():
            spoofed = self.spoofed_ids.get(component, "")
            status = "SPOOFED" if spoofed else "Original"
            tag = "spoofed" if spoofed else "original"
            
            self.hwid_tree.insert("", tk.END, values=(component, hwid, spoofed or "—", status),
                                tags=(tag,))
        
        self.hwid_tree.tag_configure("spoofed", foreground=VeniceTheme.ACCENT_BLUE_BRIGHT)
        self.hwid_tree.tag_configure("original", foreground=VeniceTheme.TEXT_SECONDARY)
    
    def spoof_hardware(self):
        """Simulate hardware spoofing"""
        self.progress_frame.pack(fill=tk.X, pady=10)
        self.spoof_btn.config_text("SPOOFING...")
        
        def spoof_thread():
            components = list(self.hardware_data.keys())
            total = len(components)
            
            for i, component in enumerate(components):
                self.progress_label.configure(
                    text=f"Spoofing {component}... ({i+1}/{total})"
                )
                self.progress["value"] = (i + 1) / total * 100
                self.root.update_idletasks()
                time.sleep(0.4)
                
                if component == "MAC Address":
                    self.spoofed_ids[component] = self.generate_mac()
                else:
                    self.spoofed_ids[component] = self.generate_hwid()
            
            self.is_spoofed = True
            self.root.after(0, self.spoof_complete)
        
        Thread(target=spoof_thread, daemon=True).start()
    
    def spoof_complete(self):
        """Called when spoofing complete"""
        self.progress_frame.pack_forget()
        self.spoof_btn.config_text("✓ SPOOFED")
        self.spoof_btn.config_bg(VeniceTheme.SUCCESS)
        self.update_hwid_tree()
        self.status_indicator.configure(text="● SPOOFED", fg=VeniceTheme.ACCENT_BLUE_BRIGHT)
        self.status_text.configure(text="Hardware IDs spoofed - Apex ready")
        
        if hasattr(self, 'activity_text'):
            self.log_activity("All hardware IDs spoofed successfully")
            self.log_activity("System ready for Apex Legends")
    
    def restore_hardware(self):
        """Restore original hardware IDs"""
        self.spoofed_ids = {}
        self.is_spoofed = False
        self.update_hwid_tree()
        self.spoof_btn.config_text("⚡ SPOOF ALL HWIDs")
        self.spoof_btn.config_bg(VeniceTheme.ACCENT_BLUE)
        self.status_indicator.configure(text="● READY", fg=VeniceTheme.SUCCESS)
        self.status_text.configure(text="Original hardware IDs restored")
        
        if hasattr(self, 'activity_text'):
            self.log_activity("Hardware IDs restored to original")
    
    def run_cleaner(self):
        """Simulate system cleaning"""
        messagebox.showinfo("System Cleaner", 
                          "Cleaning completed successfully!\n\n"
                          "Removed:\n"
                          "• Registry traces\n"
                          "• Temporary files\n"
                          "• Prefetch data\n"
                          "• Apex Legends cache")
    
    def log_activity(self, message):
        """Add activity log entry"""
        if hasattr(self, 'activity_text'):
            self.activity_text.configure(state=tk.NORMAL)
            timestamp = datetime.now().strftime("%H:%M:%S")
            self.activity_text.insert(tk.END, f"[{timestamp}] {message}\n")
            self.activity_text.configure(state=tk.DISABLED)
            self.activity_text.see(tk.END)


def main():
    root = tk.Tk()
    app = VeniceAI47(root)
    root.mainloop()


if __name__ == "__main__":
    main()