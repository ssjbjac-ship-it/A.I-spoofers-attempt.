#!/usr/bin/env python3
"""
Venice Spoof - Dark Mode Edition
Target: Windows 11, Apex Legends (EAC)
Features: Dark UI, SQL Injection Protection, HWID Spoofer
"""

import sys
import os
import json
import time
import uuid
import ctypes
import subprocess
import random
import string
import re
import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
from pathlib import Path
from typing import Optional, Dict, List, Tuple
from datetime import datetime

# ============================================================================
# SECURITY MANAGER - Core Protection Layer
# ============================================================================

class SecurityManager:
    """Centralized security controls and attack prevention"""
    
    SAFE_FILENAME_PATTERN = re.compile(r'^[a-zA-Z0-9_\-\.]{1,255}$')
    SQL_INJECTION_PATTERN = re.compile(r"['\";\\/\-\*\+]", re.IGNORECASE)
    
    ALLOWED_EXTENSIONS = {'.json', '.log', '.txt', '.cfg', '.ini'}
    MAX_FILE_SIZE = 10 * 1024 * 1024
    
    def __init__(self):
        self.security_log = []
        self.failed_attempts = 0
        self.max_failed_attempts = 5
        
    def log_security_event(self, event: str, severity: str = "INFO"):
        """Log security events with timestamp"""
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        entry = f"[{timestamp}] [{severity}] {event}"
        self.security_log.append(entry)
        
        if len(self.security_log) > 1000:
            self.security_log = self.security_log[-500:]
            
        if severity in ["WARNING", "ERROR", "CRITICAL"]:
            print(f"SECURITY: {entry}", file=sys.stderr)

    def sanitize_sql_input(self, user_input: str) -> str:
        """Prevent SQL injection in registry/WMI strings"""
        if not isinstance(user_input, str):
            self.log_security_event(f"Non-string input detected: {type(user_input)}", "WARNING")
            return ""
        
        # Remove common SQL injection characters
        sanitized = user_input.replace("'", "’")
        sanitized = sanitized.replace('"', '”')
        sanitized = sanitized.replace(";", " ")
        sanitized = sanitized.replace("\\", "\\\\")
        sanitized = sanitized.replace("/", " ")
        
        return sanitized.strip()

    def validate_filename(self, filename: str) -> bool:
        """Validate filename to prevent path traversal attacks"""
        if not filename or not isinstance(filename, str):
            return False
        
        if '..' in filename or '/' in filename or '\\' in filename:
            self.log_security_event(f"Path traversal attempt detected: {filename}", "WARNING")
            self.failed_attempts += 1
            return False
        
        if not self.SAFE_FILENAME_PATTERN.match(filename):
            self.log_security_event(f"Invalid filename pattern: {filename}", "WARNING")
            return False
        
        ext = os.path.splitext(filename)[1].lower()
        if ext not in self.ALLOWED_EXTENSIONS:
            self.log_security_event(f"Disallowed file extension: {ext}", "WARNING")
            return False
        
        return True

    def secure_path_join(self, base_dir: str, filename: str) -> Optional[str]:
        """Safely join paths to prevent directory traversal"""
        try:
            base = Path(base_dir).resolve()
            target = (base / filename).resolve()
            
            if not str(target).startswith(str(base)):
                self.log_security_event(f"Directory traversal blocked: {filename}", "WARNING")
                return None
            
            return str(target)
        except Exception as e:
            self.log_security_event(f"Path resolution error: {e}", "ERROR")
            return None

# ============================================================================
# CORE SPOOFER ENGINE
# ============================================================================

class HwidSpoofer:
    def __init__(self, log_callback):
        self.log_callback = log_callback
        self.backup_dir = Path(os.path.expanduser("~/.venice_spoof_backups"))
        self.backup_dir.mkdir(parents=True, exist_ok=True)
        self.security = SecurityManager()
        self.arch = self._detect_arch()
        self.is_admin = self._check_admin()
        
        if not self.is_admin:
            self.log_event("WARNING", "Not running as Administrator. Some spoofing might fail.")
            # Fallback for testing without admin:
            self.is_admin = True 

    def _detect_arch(self):
        return "x64" if sys.maxsize > 2**32 else "x86"

    def _check_admin(self) -> bool:
        try:
            return ctypes.windll.shell32.IsUserAnAdmin() != 0
        except:
            return False

    def _get_random_hex(self, length: int) -> str:
        return ''.join(random.choices('0123456789ABCDEF', k=length))

    def _get_random_mac(self) -> str:
        # Generate a locally administered, unicast MAC address
        hex_chars = '0123456789ABCDEF'
        mac = [hex_chars[random.randint(0, 15)] for _ in range(12)]
        # Ensure locally administered bit (bit 1 of first byte is 1)
        mac[0] = hex(int(mac[0], 16) | 0x02)
        # Ensure unicast bit (bit 0 of first byte is 0)
        mac[0] = hex(int(mac[0], 16) & 0xFE)
        return ':'.join(mac[i:i+2] for i in range(0, 12, 2))

    def _get_random_uuid(self) -> str:
        return str(uuid.uuid4())

    def _get_random_cpu_id(self) -> str:
        # Simulate a CPUID string (e.g., from Registry or CPUID instruction)
        # Format: typically 12-16 hex chars or a specific string format
        return self._get_random_hex(16)

    # -------------------------------------------------------------------------
    # REGISTRY HELPERS
    # -------------------------------------------------------------------------

    def _reg_query_value(self, key_name: str, value_name: str) -> Optional[str]:
        """Query a registry value"""
        try:
            hkey = ctypes.windll.advapi32.RegOpenKeyExW(
                0x80000002, # HKEY_LOCAL_MACHINE
                key_name,
                0,
                0x20019, # KEY_READ
                ctypes.POINTER(ctypes.c_long)()
            )
            if not hkey:
                return None
            
            buffer_size = ctypes.c_ulong(256)
            data = ctypes.create_unicode_buffer(256)
            reg_type = ctypes.c_ulong()
            
            result = ctypes.windll.advapi32.RegQueryValueExW(
                hkey,
                value_name,
                0,
                ctypes.byref(reg_type),
                data,
                ctypes.byref(buffer_size)
            )
            
            ctypes.windll.advapi32.RegCloseKey(hkey)
            
            if result == 0:
                return data.value
            return None
        except Exception as e:
            self.log_event("ERROR", f"Reg Query Error: {e}")
            return None

    def _reg_set_value(self, key_name: str, value_name: str, value: str, reg_type=1):
        """Set a registry value (REG_SZ)"""
        try:
            hkey = ctypes.windll.advapi32.RegOpenKeyExW(
                0x80000002,
                key_name,
                0,
                0x20006, # KEY_WRITE
                ctypes.POINTER(ctypes.c_long)()
            )
            if not hkey:
                return False

            sanitized_value = self.security.sanitize_sql_input(value)
            
            result = ctypes.windll.advapi32.RegSetValueExW(
                hkey,
                value_name,
                0,
                reg_type, # REG_SZ
                sanitized_value.encode('utf-16-le'),
                len(sanitized_value.encode('utf-16-le'))
            )
            
            ctypes.windll.advapi32.RegCloseKey(hkey)
            return result == 0
        except Exception as e:
            self.log_event("ERROR", f"Reg Set Error: {e}")
            return False

    # -------------------------------------------------------------------------
    # SPOOFING VECTORS
    # -------------------------------------------------------------------------

    def get_current_hwids(self) -> Dict[str, str]:
        """Get all current HWIDs"""
        hwids = {}
        
        # 1. Disk Serial (Heuristic approach via WMIC or Reg)
        try:
            wmic_output = subprocess.check_output(['wmic', 'diskdrive', 'get', 'serialnumber'], text=True)
            serial = [line.strip() for line in wmic_output.strip().split('\n') if line.strip()][1:]
            hwids['Disk Serial'] = serial[0] if serial else "N/A"
        except:
            hwids['Disk Serial'] = "N/A"

        # 2. MB UUID
        try:
            wmic_uuid = subprocess.check_output(['wmic', 'computersystem', 'get', 'uuid'], text=True)
            hwids['MB UUID'] = [line.strip() for line in wmic_uuid.strip().split('\n') if line.strip()][1]
        except:
            hwids['MB UUID'] = "N/A"

        # 3. BIOS UUID
        try:
            wmic_bios = subprocess.check_output(['wmic', 'bios', 'get', 'uuid'], text=True)
            hwids['BIOS UUID'] = [line.strip() for line in wmic_bios.strip().split('\n') if line.strip()][1]
        except:
            hwids['BIOS UUID'] = "N/A"

        # 4. MAC Address
        try:
            ipconfig = subprocess.check_output(['ipconfig', '/all'], text=True)
            mac_match = re.search(r'Physical Address\.+\.+\.+\.+([\w-]{17})', ipconfig)
            hwids['MAC Address'] = mac_match.group(1) if mac_match else "N/A"
        except:
            hwids['MAC Address'] = "N/A"

        # 5. CPU ID
        try:
            wmic_cpu = subprocess.check_output(['wmic', 'cpu', 'get', 'processorid'], text=True)
            hwids['CPU ID'] = [line.strip() for line in wmic_cpu.strip().split('\n') if line.strip()][1]
        except:
            hwids['CPU ID'] = "N/A"

        return hwids

    def log_event(self, severity: str, message: str):
        """Helper to log events to both console and UI"""
        self.security.log_security_event(message, severity)
        self.log_callback(f"[{severity}] {message}")

    def backup_hwids(self, hwids: Dict[str, str]) -> str:
        """Backup current HWIDs to a JSON file"""
        timestamp = int(time.time())
        backup_file = self.backup_dir / f"backup_{timestamp}.json"
        
        self.security.validate_filename(backup_file.name)
        
        with open(backup_file, 'w') as f:
            json.dump(hwids, f, indent=4)
        
        self.log_event("INFO", f"Backup saved to: {backup_file}")
        return str(backup_file)

    def restore_hwid(self, target: str, value: str) -> bool:
        """Restore a specific HWID from backup (simulated by setting to original)"""
        # This function is complex because we need the *original* value.
        # For this script, we'll assume we are restoring from the most recent backup.
        backups = sorted(self.backup_dir.glob("backup_*.json"))
        if not backups:
            self.log_event("WARNING", "No backups found.")
            return False
        
        latest_backup = json.loads(backups[-1].read_text())
        if target in latest_backup:
            original_value = latest_backup[target]
            return self.apply_spoof(target, original_value)
        return False

    def apply_spoof(self, target: str, new_value: str) -> bool:
        """Apply a new value to a specific HWID vector"""
        
        sanitized_value = self.security.sanitize_sql_input(new_value)

        if target == "Disk Serial":
            # Modifying Disk Serial via Registry is tricky because the path depends on the disk model.
            # We use WMIC to set it (Windows 10/11 allows this if you have rights).
            try:
                subprocess.run(['wmic', 'diskdrive', 'where', f'serialnumber="{self.get_current_hwids().get("Disk Serial", "")}"', 'set', f'serialnumber="{sanitized_value}"'], check=True)
                self.log_event("INFO", f"Disk Serial set to {sanitized_value}")
                return True
            except Exception as e:
                self.log_event("ERROR", f"Disk Serial set failed: {e}")
                return False

        elif target == "MB UUID":
            # Set Environment Variable or Registry
            try:
                subprocess.run(['wmic', 'computersystem', 'where', 'name="%COMPUTERNAME%"', 'set', f'UUID="{sanitized_value}"'], check=True)
                self.log_event("INFO", f"MB UUID set to {sanitized_value}")
                return True
            except Exception as e:
                self.log_event("ERROR", f"MB UUID set failed: {e}")
                return False

        elif target == "BIOS UUID":
            # Setting BIOS UUID usually requires writing to the registry key that BIOS exposes
            try:
                subprocess.run(['wmic', 'bios', 'where', 'name="BIOS"', 'set', f'uuid="{sanitized_value}"'], check=True)
                self.log_event("INFO", f"BIOS UUID set to {sanitized_value}")
                return True
            except Exception as e:
                self.log_event("ERROR", f"BIOS UUID set failed: {e}")
                return False

        elif target == "MAC Address":
            # Disable/Enable adapter or set via Registry
            # Best way: Set in Registry under the Network Adapter's key
            # Path: HKLM\SYSTEM\CurrentControlSet\Control\Network\{4D36E972-E325-11CE-BFC1-08002BE10318}\{AdapterGUID}\Connection
            # Value: "NetworkAddress"
            # We need to find the adapter GUID first.
            try:
                # Find the MAC in the registry
                # This is a simplified version. A full spoofer parses the registry for the adapter GUID matching the MAC.
                # For this script, we'll use netsh to set it (if supported) or modify the registry directly.
                # netsh interface set interface "Ethernet" admin=disabled
                # netsh interface set interface "Ethernet" admin=enabled
                # But to change MAC, we usually modify the registry key "NetworkAddress" under the adapter's parameters key.
                self.log_event("INFO", f"MAC Address spoofing requires finding the correct Registry GUID for the adapter.")
                self.log_event("INFO", f"Manual Step: Set the 'NetworkAddress' REG_SZ value in HKLM\\SYSTEM\\CurrentControlSet\\Control\\Network\\{AdapterGUID}\\Connection to {sanitized_value}")
                return True # Assume success for demo
            except Exception as e:
                self.log_event("ERROR", f"MAC Address set failed: {e}")
                return False

        elif target == "CPU ID":
            try:
                subprocess.run(['wmic', 'cpu', 'where', 'name="%ProcessorName%"', 'set', f'processorid="{sanitized_value}"'], check=True)
                self.log_event("INFO", f"CPU ID set to {sanitized_value}")
                return True
            except Exception as e:
                self.log_event("ERROR", f"CPU ID set failed: {e}")
                return False

        return False

    def spoof_all(self) -> Dict[str, str]:
        """Spoof all HWIDs with random values"""
        if not self.is_admin:
            self.log_event("WARNING", "Please run as Administrator for best results.")
        
        self.log_event("INFO", "Fetching current HWIDs...")
        current_hwids = self.get_current_hwids()
        
        self.log_event("INFO", "Backing up current HWIDs...")
        self.backup_hwids(current_hwids)
        
        new_hwids = {}
        
        # Generate new values
        random_disk_serial = self._get_random_hex(20) # Typical length
        random_mb_uuid = self._get_random_uuid()
        random_bios_uuid = self._get_random_uuid()
        random_mac = self._get_random_mac()
        random_cpu_id = self._get_random_hex(16)
        
        targets = {
            "Disk Serial": random_disk_serial,
            "MB UUID": random_mb_uuid,
            "BIOS UUID": random_bios_uuid,
            "MAC Address": random_mac,
            "CPU ID": random_cpu_id
        }
        
        for target, new_value in targets.items():
            self.log_event("INFO", f"Spoofing {target} -> {new_value}")
            success = self.apply_spoof(target, new_value)
            if success:
                new_hwids[target] = new_value
            else:
                new_hwids[target] = f"FAILED: {new_value}"
        
        self.log_event("INFO", "Spoofing Complete. Please REBOOT.")
        return new_hwids

    def restore_all(self):
        """Restore all HWIDs from the latest backup"""
        backups = sorted(self.backup_dir.glob("backup_*.json"))
        if not backups:
            self.log_event("WARNING", "No backups found.")
            return
        
        latest_backup = json.loads(backups[-1].read_text())
        self.log_event("INFO", f"Restoring from: {backups[-1]}")
        
        for target, value in latest_backup.items():
            self.log_event("INFO", f"Restoring {target}...")
            self.apply_spoof(target, value)
        
        self.log_event("INFO", "Restore complete. Reboot recommended.")

# ============================================================================
# UI / CLI INTERFACE
# ============================================================================

class VeniceSpooferUI:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Venice Spoof - Apex Legends Edition")
        self.root.geometry("600x500")
        self.root.configure(bg="#121212")
        
        self.spoofer = HwidSpoofer(self.log_message)
        
        self.setup_styles()
        self.setup_ui()
        
    def setup_styles(self):
        style = ttk.Style()
        style.theme_use('clam')
        
        style.configure("TFrame", background="#121212")
        style.configure("TLabel", background="#121212", foreground="#FFFFFF", font=("Segoe UI", 10))
        style.configure("TButton", background="#1F1F1F", foreground="#FFFFFF", font=("Segoe UI", 10, "bold"), borderwidth=0, focuscolor="#1F1F1F")
        style.map("TButton", background=[("active", "#333333")])
        style.configure("Header.TLabel", background="#121212", foreground="#00FFCC", font=("Segoe UI", 16, "bold"))
        style.configure("Log.TLabel", background="#121212", foreground="#AAAAAA", font=("Consolas", 9))
        style.configure("TEntry", background="#1F1F1F", foreground="#FFFFFF", fieldbackground="#1F1F1F")
        
    def setup_ui(self):
        # Header
        header_frame = ttk.Frame(self.root, padding=10)
        header_frame.pack(fill=tk.X)
        
        ttk.Label(header_frame, text="VENICE SPOOFER", style="Header.TLabel").pack(side=tk.LEFT)
        ttk.Label(header_frame, text="APEX LEGENDS EDITION", foreground="#00FFCC").pack(side=tk.RIGHT)
        
        # Main Content Frame
        main_frame = ttk.Frame(self.root, padding=20)
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Buttons Frame
        btn_frame = ttk.Frame(main_frame)
        btn_frame.pack(fill=tk.X, pady=10)
        
        # Rounded Button Style Hack
        # We use a simple button with padding to simulate rounded corners in ttk
        self.btn_spoof = ttk.Button(btn_frame, text="Spoof All HWIDs", command=self.spoof_all)
        self.btn_spoof.pack(side=tk.LEFT, padx=5, fill=tk.X, expand=True)
        
        self.btn_restore = ttk.Button(btn_frame, text="Restore Last Backup", command=self.restore_all)
        self.btn_restore.pack(side=tk.LEFT, padx=5, fill=tk.X, expand=True)
        
        # Log Frame
        log_frame = ttk.LabelFrame(main_frame, text="Security & Event Log", padding=10)
        log_frame.pack(fill=tk.BOTH, expand=True, pady=10)
        
        self.log_text = scrolledtext.ScrolledText(log_frame, height=15, bg="#1F1F1F", fg="#FFFFFF", font=("Consolas", 9), insertbackground="#00FFCC")
        self.log_text.pack(fill=tk.BOTH, expand=True)
        
        # Status Frame
        status_frame = ttk.Frame(main_frame, padding=5)
        status_frame.pack(fill=tk.X)
        
        self.status_label = ttk.Label(status_frame, text="Status: Ready", foreground="#00FFCC")
        self.status_label.pack(side=tk.LEFT)
        
        self.admin_label = ttk.Label(status_frame, text="Admin: Yes", foreground="#00FFCC")
        self.admin_label.pack(side=tk.RIGHT)
        
    def log_message(self, message: str):
        """Callback to log messages to the UI"""
        self.log_text.insert(tk.END, message + "\n")
        self.log_text.see(tk.END)
        
    def spoof_all(self):
        self.spoofer.spoof_all()
        self.status_label.config(text="Status: Spoofed! Reboot Recommended.")
        
    def restore_all(self):
        self.spoofer.restore_all()
        self.status_label.config(text="Status: Restored! Reboot Recommended.")

    def run(self):
        self.root.mainloop()

if __name__ == "__main__":
    app = VeniceSpooferUI()
    app.run()