import tkinter as tk
from tkinter import ttk, messagebox
import subprocess
import platform
import uuid
import hashlib
import threading
import os
import json
import random
import string
import ctypes
from datetime import datetime

# ============================================================
# CONFIGURATION
# ============================================================

BG = "#0d0b0c"
PANEL = "#171214"
PANEL_2 = "#21191b"

TEXT = "#f4eeee"
SECONDARY = "#a99b9e"

WINE = "#722f37"
WINE_HOVER = "#8f3d47"
WINE_DARK = "#4f2026"

BORDER = "#302326"
GREEN = "#2d7d46"
GREEN_HOVER = "#3a9a59"
RED = "#7d2d2d"

# ============================================================
# ADMIN CHECK
# ============================================================

def is_admin():
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except:
        return False

def request_admin():
    if not is_admin():
        ctypes.windll.shell32.ShellExecuteW(None, "runas", sys.executable, " ".join(sys.argv), None, 1)
        sys.exit()

# ============================================================
# HWID SPOOFER CORE
# ============================================================

class HWIDSpoofer:
    def __init__(self):
        self.original_data = {}
        self.spoofed_data = {}
        self.backup_path = os.path.join(os.environ['APPDATA'], 'Verify', 'backup.json')
        
        # Create backup directory
        os.makedirs(os.path.dirname(self.backup_path), exist_ok=True)
        
    def get_hardware_data(self):
        """Collect current hardware information"""
        data = {}
        
        # System
        data["Computer Name"] = platform.node()
        data["Operating System"] = platform.platform()
        
        # BIOS
        data["BIOS Serial"] = self._powershell("(Get-CimInstance Win32_BIOS).SerialNumber")
        data["BIOS Version"] = self._powershell("(Get-CimInstance Win32_BIOS).SMBIOSBIOSVersion")
        
        # Motherboard
        data["Motherboard Serial"] = self._powershell("(Get-CimInstance Win32_BaseBoard).SerialNumber")
        data["Motherboard Model"] = self._powershell("(Get-CimInstance Win32_BaseBoard).Product")
        
        # System UUID
        data["System UUID"] = self._powershell("(Get-CimInstance Win32_ComputerSystemProduct).UUID")
        
        # CPU
        data["CPU ID"] = self._powershell("(Get-CimInstance Win32_Processor).ProcessorId")
        
        # Windows GUID
        data["Machine GUID"] = self._powershell("(Get-ItemProperty 'HKLM:\\SOFTWARE\\Microsoft\\Cryptography').MachineGuid")
        
        # MAC Addresses
        data["MAC Addresses"] = self._powershell("(Get-CimInstance Win32_NetworkAdapterConfiguration | Where-Object {$_.MACAddress} | Select-Object -ExpandProperty MACAddress) -join ' | '")
        
        # Disk Serial Numbers
        data["Disk Serial Numbers"] = self._powershell("(Get-CimInstance Win32_DiskDrive | Select-Object -ExpandProperty SerialNumber) -join ' | '")
        
        return data
    
    def _powershell(self, command):
        """Execute PowerShell command and return output"""
        try:
            result = subprocess.run(
                ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", command],
                capture_output=True,
                text=True,
                timeout=10
            )
            output = result.stdout.strip()
            return output if output else "Unavailable"
        except Exception:
            return "Unavailable"
    
    def _generate_spoofed_value(self, original, value_type):
        """Generate a spoofed value based on type"""
        if original == "Unavailable" or not original:
            return "Unavailable"
            
        if value_type == "serial":
            # Generate similar format serial (alphanumeric, same length)
            length = len(original)
            chars = string.ascii_uppercase + string.digits
            return ''.join(random.choices(chars, k=length))
        
        elif value_type == "uuid":
            return str(uuid.uuid4()).upper()
        
        elif value_type == "mac":
            # Generate random MAC address
            mac = [0x02, 0x00, 0x00, 
                   random.randint(0x00, 0x7f), 
                   random.randint(0x00, 0xff), 
                   random.randint(0x00, 0xff)]
            return ':'.join(map(lambda x: "%02x" % x, mac))
        
        elif value_type == "cpu":
            # Generate random CPU ID
            return ''.join(random.choices(string.hexdigits.upper(), k=len(original)))
        
        elif value_type == "guid":
            return str(uuid.uuid4())
        
        elif value_type == "name":
            # Computer name
            prefixes = ["DESKTOP", "PC", "WORKSTATION", "LAPTOP"]
            suffix = ''.join(random.choices(string.ascii_uppercase + string.digits, k=6))
            return f"{random.choice(prefixes)}-{suffix}"
        
        else:
            return original + "_SPOOFED"
    
    def generate_spoofed_data(self, original_data):
        """Generate spoofed values for all hardware identifiers"""
        spoofed = {}
        
        spoofed["Computer Name"] = self._generate_spoofed_value(original_data["Computer Name"], "name")
        spoofed["BIOS Serial"] = self._generate_spoofed_value(original_data["BIOS Serial"], "serial")
        spoofed["BIOS Version"] = self._generate_spoofed_value(original_data["BIOS Version"], "serial")
        spoofed["Motherboard Serial"] = self._generate_spoofed_value(original_data["Motherboard Serial"], "serial")
        spoofed["Motherboard Model"] = self._generate_spoofed_value(original_data["Motherboard Model"], "serial")
        spoofed["System UUID"] = self._generate_spoofed_value(original_data["System UUID"], "uuid")
        spoofed["CPU ID"] = self._generate_spoofed_value(original_data["CPU ID"], "cpu")
        spoofed["Machine GUID"] = self._generate_spoofed_value(original_data["Machine GUID"], "guid")
        spoofed["MAC Addresses"] = self._generate_spoofed_value(original_data["MAC Addresses"], "mac")
        spoofed["Disk Serial Numbers"] = self._generate_spoofed_value(original_data["Disk Serial Numbers"], "serial")
        
        return spoofed
    
    def apply_spoof(self, spoofed_data):
        """Apply spoofed values to the system (requires admin)"""
        if not is_admin():
            return False, "Administrator privileges required!"
        
        try:
            # Create backup before applying
            self.save_backup()
            
            # Apply spoofed computer name
            if spoofed_data["Computer Name"] != "Unavailable":
                self._set_computer_name(spoofed_data["Computer Name"])
            
            # Apply spoofed Machine GUID
            if spoofed_data["Machine GUID"] != "Unavailable":
                self._set_machine_guid(spoofed_data["Machine GUID"])
            
            # Apply spoofed MAC address (requires registry modifications)
            if spoofed_data["MAC Addresses"] != "Unavailable":
                self._set_mac_address(spoofed_data["MAC Addresses"])
            
            # Apply spoofed BIOS serial
            if spoofed_data["BIOS Serial"] != "Unavailable":
                self._set_bios_serial(spoofed_data["BIOS Serial"])
            
            # Apply spoofed motherboard serial
            if spoofed_data["Motherboard Serial"] != "Unavailable":
                self._set_motherboard_serial(spoofed_data["Motherboard Serial"])
            
            return True, "HWID spoofed successfully! A reboot is required for all changes to take effect."
            
        except Exception as e:
            return False, f"Error applying spoof: {str(e)}"
    
    def _set_computer_name(self, new_name):
        """Change computer name"""
        try:
            subprocess.run(
                f'wmic computersystem where name="%computername%" call rename name="{new_name}"',
                shell=True,
                capture_output=True
            )
        except Exception:
            pass
    
    def _set_machine_guid(self, new_guid):
        """Change Windows Machine GUID in registry"""
        try:
            import winreg
            key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Cryptography", 0, winreg.KEY_SET_VALUE)
            winreg.SetValueEx(key, "MachineGuid", 0, winreg.REG_SZ, new_guid)
            winreg.CloseKey(key)
        except Exception:
            pass
    
    def _set_mac_address(self, new_mac):
        """Change MAC address (simplified - actually requires network adapter specific changes)"""
        # This is a simplified version - real MAC spoofing requires more complex registry modifications
        try:
            import winreg
            # Get network adapters
            key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SYSTEM\CurrentControlSet\Control\Class\{4d36e972-e325-11ce-bfc1-08002be10318}", 0, winreg.KEY_READ)
            index = 0
            while True:
                try:
                    subkey = winreg.EnumKey(key, index)
                    adapter_key = winreg.OpenKey(key, subkey, 0, winreg.KEY_SET_VALUE)
                    try:
                        # Check if this is a valid adapter
                        adapter_name, _ = winreg.QueryValueEx(adapter_key, "DriverDesc")
                        # Set MAC address
                        mac_clean = new_mac.replace(":", "").replace("-", "")
                        winreg.SetValueEx(adapter_key, "NetworkAddress", 0, winreg.REG_SZ, mac_clean)
                        winreg.CloseKey(adapter_key)
                        break
                    except:
                        winreg.CloseKey(adapter_key)
                    index += 1
                except WindowsError:
                    break
            winreg.CloseKey(key)
        except Exception:
            pass
    
    def _set_bios_serial(self, new_serial):
        """Change BIOS serial number (registry method)"""
        try:
            import winreg
            key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SYSTEM\CurrentControlSet\Services\mssmbios\Data", 0, winreg.KEY_SET_VALUE)
            # Note: This is a simplified approach - real BIOS serial changes require more complex methods
            winreg.SetValueEx(key, "SMBiosData", 0, winreg.REG_BINARY, b'')
            winreg.CloseKey(key)
        except Exception:
            pass
    
    def _set_motherboard_serial(self, new_serial):
        """Change motherboard serial number"""
        try:
            import winreg
            key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"HARDWARE\DESCRIPTION\System", 0, winreg.KEY_SET_VALUE)
            winreg.SetValueEx(key, "SystemBiosVersion", 0, winreg.REG_SZ, new_serial)
            winreg.CloseKey(key)
        except Exception:
            pass
    
    def save_backup(self):
        """Save current hardware data as backup"""
        current_data = self.get_hardware_data()
        with open(self.backup_path, 'w') as f:
            json.dump(current_data, f, indent=2)
    
    def restore_backup(self):
        """Restore original hardware data from backup"""
        if not is_admin():
            return False, "Administrator privileges required!"
        
        try:
            if not os.path.exists(self.backup_path):
                return False, "No backup found!"
            
            with open(self.backup_path, 'r') as f:
                original_data = json.load(f)
            
            # Restore computer name
            if original_data.get("Computer Name"):
                self._set_computer_name(original_data["Computer Name"])
            
            # Restore Machine GUID
            if original_data.get("Machine GUID"):
                self._set_machine_guid(original_data["Machine GUID"])
            
            return True, "Backup restored successfully! A reboot is required."
            
        except Exception as e:
            return False, f"Error restoring backup: {str(e)}"

# ============================================================
# VERIFY APPLICATION
# ============================================================

class VerifyApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Verify - HWID Spoofer")
        self.root.geometry("1100x750")
        self.root.minsize(900, 650)
        self.root.configure(bg=BG)
        
        self.spoofer = HWIDSpoofer()
        self.current_data = {}
        self.spoofed_data = {}
        
        # Check for admin privileges on startup
        if not is_admin():
            messagebox.showwarning("Admin Required", "Verify requires administrator privileges to spoof HWID. Please run as administrator.")
        
        self.setup_styles()
        self.create_interface()
        self.refresh()
    
    def setup_styles(self):
        style = ttk.Style()
        style.theme_use("clam")
        
        style.configure("TNotebook", background=BG, borderwidth=0)
        style.configure("TNotebook.Tab", 
                       background=PANEL, 
                       foreground=SECONDARY,
                       padding=(24, 13),
                       borderwidth=0,
                       font=("Georgia", 10))
        style.map("TNotebook.Tab",
                 background=[("selected", WINE)],
                 foreground=[("selected", TEXT)])
    
    def create_interface(self):
        # Header
        header = tk.Frame(self.root, bg=BG)
        header.pack(fill="x", padx=35, pady=(28, 8))
        
        title = tk.Label(header, text="Verify", bg=BG, fg=TEXT, 
                        font=("Georgia", 32, "bold italic"))
        title.pack(anchor="w")
        
        subtitle = tk.Label(header, text="Hardware ID Spoofer", 
                           bg=BG, fg=SECONDARY, font=("Georgia", 10, "italic"))
        subtitle.pack(anchor="w", pady=(2, 0))
        
        # Status
        self.status_frame = tk.Frame(self.root, bg=PANEL_2)
        self.status_frame.pack(fill="x", padx=35, pady=(10, 15))
        
        self.status_label = tk.Label(self.status_frame, text="● Ready", 
                                     bg=PANEL_2, fg=GREEN, font=("Consolas", 10))
        self.status_label.pack(side="left", padx=15, pady=8)
        
        self.admin_label = tk.Label(self.status_frame, 
                                    text="✓ Admin" if is_admin() else "✗ Not Admin", 
                                    bg=PANEL_2, 
                                    fg=GREEN if is_admin() else RED,
                                    font=("Consolas", 10))
        self.admin_label.pack(side="right", padx=15, pady=8)
        
        # Notebook
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill="both", expand=True, padx=25, pady=15)
        
        # Tabs
        self.create_overview_tab()
        self.create_spoof_tab()
        self.create_backup_tab()
    
    def create_button(self, parent, text, command, bg_color=WINE, width=None):
        button = tk.Button(parent, text=text, command=command,
                          bg=bg_color, fg=TEXT, activebackground=WINE_HOVER,
                          activeforeground=TEXT, font=("Georgia", 10, "bold"),
                          relief="flat", borderwidth=0, padx=24, pady=11,
                          cursor="hand2", width=width)
        button.bind("<Enter>", lambda e: button.configure(bg=WINE_HOVER if bg_color == WINE else GREEN_HOVER))
        button.bind("<Leave>", lambda e: button.configure(bg=bg_color))
        return button
    
    # ============================================================
    # OVERVIEW TAB
    # ============================================================
    
    def create_overview_tab(self):
        tab = tk.Frame(self.notebook, bg=BG)
        self.notebook.add(tab, text="  Overview  ")
        
        # Current Hardware Info
        info_frame = tk.Frame(tab, bg=PANEL, highlightbackground=BORDER, highlightthickness=1)
        info_frame.pack(fill="both", expand=True, padx=20, pady=15)
        
        tk.Label(info_frame, text="Current Hardware Information", 
                bg=PANEL, fg=TEXT, font=("Georgia", 16, "bold")).pack(pady=(20, 10))
        
        # Scrollable text widget
        text_frame = tk.Frame(info_frame, bg=PANEL)
        text_frame.pack(fill="both", expand=True, padx=15, pady=10)
        
        scrollbar = tk.Scrollbar(text_frame)
        scrollbar.pack(side="right", fill="y")
        
        self.info_text = tk.Text(text_frame, bg=PANEL, fg=TEXT, 
                                 insertbackground=TEXT, selectbackground=WINE,
                                 font=("Consolas", 10), relief="flat", wrap="word",
                                 yscrollcommand=scrollbar.set)
        self.info_text.pack(fill="both", expand=True)
        scrollbar.config(command=self.info_text.yview)
        
        # Refresh button
        self.create_button(tab, "⟳ Refresh", self.refresh).pack(pady=15)
    
    # ============================================================
    # SPOOF TAB
    # ============================================================
    
    def create_spoof_tab(self):
        tab = tk.Frame(self.notebook, bg=BG)
        self.notebook.add(tab, text="  Spoof HWID  ")
        
        # Status card
        status_card = tk.Frame(tab, bg=PANEL_2, highlightbackground=BORDER, highlightthickness=1)
        status_card.pack(fill="x", padx=30, pady=20)
        
        tk.Label(status_card, text="Spoof Status", bg=PANEL_2, fg=SECONDARY,
                font=("Georgia", 11)).pack(pady=(15, 5))
        
        self.spoof_status = tk.Label(status_card, text="No spoof applied", 
                                     bg=PANEL_2, fg=TEXT, font=("Georgia", 12))
        self.spoof_status.pack(pady=(0, 15))
        
        # Spoof options
        options_frame = tk.Frame(tab, bg=PANEL, highlightbackground=BORDER, highlightthickness=1)
        options_frame.pack(fill="both", expand=True, padx=30, pady=10)
        
        tk.Label(options_frame, text="Spoof Options", bg=PANEL, fg=TEXT,
                font=("Georgia", 14, "bold")).pack(pady=(20, 15))
        
        # Spoof all button
        btn_frame = tk.Frame(options_frame, bg=PANEL)
        btn_frame.pack(pady=10)
        
        self.create_button(btn_frame, "Generate New Spoof", self.generate_spoof, WINE, 20).pack(side="left", padx=10)
        self.create_button(btn_frame, "Apply Spoof", self.apply_spoof, WINE, 20).pack(side="left", padx=10)
        self.create_button(btn_frame, "Randomize All", self.randomize_all, WINE, 20).pack(side="left", padx=10)
        
        # Spoofed values display
        display_frame = tk.Frame(options_frame, bg=PANEL_2)
        display_frame.pack(fill="both", expand=True, padx=20, pady=15)
        
        tk.Label(display_frame, text="Spoofed Values (Preview)", 
                bg=PANEL_2, fg=SECONDARY, font=("Georgia", 11)).pack(pady=(10, 5))
        
        scrollbar = tk.Scrollbar(display_frame)
        scrollbar.pack(side="right", fill="y")
        
        self.spoof_text = tk.Text(display_frame, bg=PANEL_2, fg=TEXT,
                                 insertbackground=TEXT, selectbackground=WINE,
                                 font=("Consolas", 10), relief="flat", wrap="word",
                                 height=12, yscrollcommand=scrollbar.set)
        self.spoof_text.pack(fill="both", expand=True, padx=10, pady=10)
        scrollbar.config(command=self.spoof_text.yview)
        
        self.spoof_text.config(state="disabled")
        
        # Warning
        warning = tk.Label(tab, text="⚠ WARNING: Spoofing may violate terms of service. Use responsibly.",
                          bg=BG, fg=RED, font=("Georgia", 9, "italic"))
        warning.pack(pady=10)
    
    # ============================================================
    # BACKUP TAB
    # ============================================================
    
    def create_backup_tab(self):
        tab = tk.Frame(self.notebook, bg=BG)
        self.notebook.add(tab, text="  Backup & Restore  ")
        
        # Backup info
        info_card = tk.Frame(tab, bg=PANEL, highlightbackground=BORDER, highlightthickness=1)
        info_card.pack(fill="x", padx=30, pady=20)
        
        tk.Label(info_card, text="Backup Management", bg=PANEL, fg=TEXT,
                font=("Georgia", 14, "bold")).pack(pady=(20, 10))
        
        tk.Label(info_card, text="Always backup your original HWID before spoofing", 
                bg=PANEL, fg=SECONDARY, font=("Georgia", 10)).pack(pady=(0, 15))
        
        # Buttons
        btn_frame = tk.Frame(info_card, bg=PANEL)
        btn_frame.pack(pady=15)
        
        self.create_button(btn_frame, "Create Backup", self.create_backup, WINE, 18).pack(side="left", padx=10)
        self.create_button(btn_frame, "Restore Backup", self.restore_backup, WINE, 18).pack(side="left", padx=10)
        
        # Backup info
        self.backup_info = tk.Label(info_card, text="No backup found", 
                                    bg=PANEL, fg=SECONDARY, font=("Consolas", 10))
        self.backup_info.pack(pady=(0, 20))
        
        # Restore warning
        warning = tk.Label(tab, text="⚠ Restoring backup will revert all HWID changes",
                          bg=BG, fg=RED, font=("Georgia", 9, "italic"))
        warning.pack(pady=10)
        
        # Footer
        footer = tk.Label(tab, text="Verify v1.0 - HWID Spoofer",
                         bg=BG, fg=SECONDARY, font=("Georgia", 9, "italic"))
        footer.pack(side="bottom", pady=20)
    
    # ============================================================
    # CORE FUNCTIONS
    # ============================================================
    
    def refresh(self):
        """Refresh hardware information"""
        self.status_label.config(text="● Scanning...", fg=WINE_HOVER)
        self.info_text.config(state="normal")
        self.info_text.delete("1.0", tk.END)
        self.info_text.insert("1.0", "Collecting hardware information...")
        self.info_text.config(state="disabled")
        
        thread = threading.Thread(target=self._scan_thread, daemon=True)
        thread.start()
    
    def _scan_thread(self):
        data = self.spoofer.get_hardware_data()
        self.root.after(0, lambda: self._update_scan(data))
    
    def _update_scan(self, data):
        self.current_data = data
        self.status_label.config(text="● Ready", fg=GREEN)
        
        # Update info text
        self.info_text.config(state="normal")
        self.info_text.delete("1.0", tk.END)
        
        for key, value in data.items():
            self.info_text.insert(tk.END, f"{key}:\n")
            self.info_text.insert(tk.END, f"  {value}\n\n")
        
        self.info_text.config(state="disabled")
        
        # Update backup info
        if os.path.exists(self.spoofer.backup_path):
            with open(self.spoofer.backup_path, 'r') as f:
                backup_data = json.load(f)
            self.backup_info.config(text=f"✅ Backup exists: {len(backup_data)} items saved")
    
    def generate_spoof(self):
        """Generate spoofed values"""
        if not self.current_data:
            messagebox.showwarning("No Data", "Please refresh system information first.")
            return
        
        self.status_label.config(text="● Generating spoof...", fg=WINE_HOVER)
        
        thread = threading.Thread(target=self._generate_thread, daemon=True)
        thread.start()
    
    def _generate_thread(self):
        spoofed = self.spoofer.generate_spoofed_data(self.current_data)
        self.root.after(0, lambda: self._update_spoof(spoofed))
    
    def _update_spoof(self, spoofed):
        self.spoofed_data = spoofed
        self.spoof_status.config(text="Spoof generated - Ready to apply", fg=GREEN)
        
        self.spoof_text.config(state="normal")
        self.spoof_text.delete("1.0", tk.END)
        
        for key, value in spoofed.items():
            original = self.current_data.get(key, "N/A")
            self.spoof_text.insert(tk.END, f"{key}:\n")
            self.spoof_text.insert(tk.END, f"  Original: {original}\n")
            self.spoof_text.insert(tk.END, f"  Spoofed:  {value}\n\n")
        
        self.spoof_text.config(state="disabled")
        self.status_label.config(text="● Ready", fg=GREEN)
    
    def randomize_all(self):
        """Randomize all spoofed values"""
        if not self.current_data:
            messagebox.showwarning("No Data", "Please refresh system information first.")
            return
        
        spoofed = self.spoofer.generate_spoofed_data(self.current_data)
        self._update_spoof(spoofed)
        messagebox.showinfo("Randomized", "All spoofed values have been regenerated randomly.")
    
    def apply_spoof(self):
        """Apply spoofed values to the system"""
        if not self.spoofed_data:
            messagebox.showwarning("No Spoof", "Please generate spoofed values first.")
            return
        
        if not is_admin():
            messagebox.showerror("Admin Required", "Administrator privileges required to apply spoof!")
            return
        
        result = messagebox.askyesno("Confirm Spoof", 
            "This will modify system identifiers. A reboot will be required.\n\n"
            "Do you want to continue?")
        
        if not result:
            return
        
        self.status_label.config(text="● Applying spoof...", fg=WINE_HOVER)
        
        thread = threading.Thread(target=self._apply_thread, daemon=True)
        thread.start()
    
    def _apply_thread(self):
        success, message = self.spoofer.apply_spoof(self.spoofed_data)
        self.root.after(0, lambda: self._update_apply(success, message))
    
    def _update_apply(self, success, message):
        if success:
            self.spoof_status.config(text="✅ Spoof applied!", fg=GREEN)
            self.status_label.config(text="● Spoofed", fg=GREEN)
            messagebox.showinfo("Success", message)
        else:
            self.spoof_status.config(text="❌ Failed to apply spoof", fg=RED)
            self.status_label.config(text="● Error", fg=RED)
            messagebox.showerror("Error", message)
    
    def create_backup(self):
        """Create backup of current HWID"""
        try:
            self.spoofer.save_backup()
            self.backup_info.config(text="✅ Backup created successfully!")
            messagebox.showinfo("Backup", "Backup saved to:\n" + self.spoofer.backup_path)
        except Exception as e:
            messagebox.showerror("Backup Failed", f"Error: {str(e)}")
    
    def restore_backup(self):
        """Restore HWID from backup"""
        result = messagebox.askyesno("Confirm Restore", 
            "This will restore your original HWID. A reboot will be required.\n\n"
            "Do you want to continue?")
        
        if not result:
            return
        
        if not is_admin():
            messagebox.showerror("Admin Required", "Administrator privileges required!")
            return
        
        self.status_label.config(text="● Restoring...", fg=WINE_HOVER)
        
        thread = threading.Thread(target=self._restore_thread, daemon=True)
        thread.start()
    
    def _restore_thread(self):
        success, message = self.spoofer.restore_backup()
        self.root.after(0, lambda: self._update_restore(success, message))
    
    def _update_restore(self, success, message):
        if success:
            self.spoof_status.config(text="✅ Backup restored!", fg=GREEN)
            self.status_label.config(text="● Ready", fg=GREEN)
            messagebox.showinfo("Success", message)
            self.refresh()
        else:
            self.status_label.config(text="● Error", fg=RED)
            messagebox.showerror("Error", message)

# ============================================================
# START
# ============================================================

if __name__ == "__main__":
    # Check admin on startup
    if not is_admin():
        response = messagebox.askyesno("Admin Required", 
            "Verify requires administrator privileges to function properly.\n\n"
            "Do you want to run as administrator?")
        if response:
            ctypes.windll.shell32.ShellExecuteW(None, "runas", sys.executable, " ".join(sys.argv), None, 1)
            sys.exit()
    
    root = tk.Tk()
    app = VerifyApp(root)
    root.mainloop()